//
//  LD_NaviViewController.h
//  Elves bookcase
//
//  Created by LD on 16/3/27.
//  Copyright © 2016年 LiDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDNaviViewController : UINavigationController


@end
