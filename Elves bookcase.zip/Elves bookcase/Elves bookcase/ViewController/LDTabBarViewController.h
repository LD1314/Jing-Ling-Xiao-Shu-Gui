//
//  LD_TabBarViewController.h
//  Elves bookcase
//
//  Created by LD on 16/3/26.
//  Copyright © 2016年 LiDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDTabBarViewController : UITabBarController

@end
