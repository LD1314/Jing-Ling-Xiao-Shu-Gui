//
//  LDBookClassTableViewController.h
//  Elves bookcase
//
//  Created by LD on 16/4/8.
//  Copyright © 2016年 LiDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDBookClassTableViewController : UITableViewController

@end
