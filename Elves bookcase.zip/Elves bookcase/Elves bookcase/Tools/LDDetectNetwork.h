//
//  LDDetectNetwork.h
//  Elves bookcase
//
//  Created by LD on 16/4/27.
//  Copyright © 2016年 LiDing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LDDetectNetwork : NSObject

- (BOOL)NetworkIsAvailable;

@end
