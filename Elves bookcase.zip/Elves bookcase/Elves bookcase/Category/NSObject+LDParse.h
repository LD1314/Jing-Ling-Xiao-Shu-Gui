//
//  NSObject+LDParse.h
//  Elves bookcase
//
//  Created by LD on 16/4/7.
//  Copyright © 2016年 LiDing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (LDParse)
//解析JSON
+ (id)parseJSON:(id)json;

@end
